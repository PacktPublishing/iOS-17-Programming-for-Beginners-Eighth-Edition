//
//  MapView.swift
//  JRNLSwiftUI
//
//  Created by shah on 14/10/2023.
//

import SwiftUI
import MapKit

struct MapView: View {
    var journalEntry: JournalEntry
    var body: some View {
        Map(bounds: MapCameraBounds(minimumDistance: 4500, maximumDistance: 4500)) {
            Marker(journalEntry.entryTitle, coordinate: CLLocationCoordinate2D(latitude:
            journalEntry.latitude ?? 0.0, longitude: journalEntry.longitude ?? 0.0))
        }
    }
}

#Preview {
    MapView(journalEntry: testData[0])
}
