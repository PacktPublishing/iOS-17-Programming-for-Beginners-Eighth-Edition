//
//  JRNLSwiftUIApp.swift
//  JRNLSwiftUI
//
//  Created by myadmin on 18/08/2023.
//

import SwiftUI

@main
struct JRNLSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
