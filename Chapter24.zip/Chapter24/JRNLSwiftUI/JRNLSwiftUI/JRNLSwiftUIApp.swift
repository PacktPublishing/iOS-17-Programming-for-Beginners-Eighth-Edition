//
//  JRNLSwiftUIApp.swift
//  JRNLSwiftUI
//
//  Created by shah on 14/10/2023.
//

import SwiftUI

@main
struct JRNLSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
