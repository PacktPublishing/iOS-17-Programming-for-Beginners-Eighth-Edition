//
//  JRNLSwiftUIApp.swift
//  JRNLSwiftUI
//
//  Created by iOS17Programming on 16/10/2023.
//

import SwiftUI

@main
struct JRNLSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
