//
//  JournalEntry.swift
//  JRNL
//
//  Created by myadmin on 25/04/2023.
//

import UIKit

struct JournalEntry: Identifiable, Hashable {
    //MARK: - Properties
    let id = UUID()
    let date = Date()
    let rating: Int
    let entryTitle: String
    let entryBody: String
    let photo: UIImage?
    let latitude: Double?
    let longitude: Double?
}

//MARK: - Sample data
let testData = [
    JournalEntry(rating: 5, entryTitle: "Today is a good day", entryBody: "I got top marks in my exam today! Great!", photo: UIImage(systemName: "sun.max"), latitude: 37.3346, longitude: -122.0090),
    JournalEntry(rating: 0, entryTitle: "Today is a bad day", entryBody: "I wasn't feeling very well today.", photo: UIImage(systemName: "cloud"), latitude: nil, longitude: nil),
    JournalEntry(rating: 3, entryTitle: "Today is an OK day", entryBody: "Just having a nice lazy day at home", photo: UIImage(systemName: "cloud.sun"), latitude: nil, longitude: nil)
]


