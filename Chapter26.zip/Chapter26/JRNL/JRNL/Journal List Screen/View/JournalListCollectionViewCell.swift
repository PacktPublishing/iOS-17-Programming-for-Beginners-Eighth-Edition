//
//  JournalListTableViewCell.swift
//  JRNL
//
//  Created by myadmin on 25/04/2023.
//

import UIKit

class JournalListCollectionViewCell: UICollectionViewCell {
    // MARK: - Properties
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!
    
    // MARK: - Init
    override init(frame: CGRect) {
        super .init(frame: frame)
        self.hoverStyle =
            .init(effect: .highlight, shape: .rect(cornerRadius: 8.0)
            )
    }
    
    required init?(coder: NSCoder) {
        super .init(coder: coder)
        self.hoverStyle =
            .init(effect: .highlight, shape: .rect(cornerRadius: 8.0)
            )
    }
}
