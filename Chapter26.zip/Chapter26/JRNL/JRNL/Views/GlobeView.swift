//
//  GlobeView.swift
//  JRNL
//
//  Created by iOS17Programming on 17/10/2023.
//

import SwiftUI
import RealityKit

struct GlobeView: View {
    var body: some View {
        #if os(xrOS)
        VStack {
            Model3D(named: "globe") {
                model in model
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            } placeholder: {
                ProgressView()
            }
        }
        #endif
    }
}

#Preview {
    GlobeView()
}
