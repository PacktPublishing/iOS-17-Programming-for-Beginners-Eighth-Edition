//
//  GlobeView.swift
//  JRNL
//
//  Created by myadmin on 09/09/2023.
//

import SwiftUI
import RealityKit

struct GlobeView: View {
    var body: some View {
#if os(xrOS)
        VStack{
            
            Model3D(named: "globe") { model in model
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            } placeholder: {
                ProgressView()
            }
            
        }
#endif
    }
}

#Preview {
    GlobeView()
}
