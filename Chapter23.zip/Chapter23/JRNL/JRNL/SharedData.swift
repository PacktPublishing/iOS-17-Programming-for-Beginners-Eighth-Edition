//
//  SharedData.swift
//  JRNL
//
//  Created by myadmin on 08/02/2024.
//

import Foundation
import SwiftData

class SharedData {
    static var shared = SharedData()
    var container: ModelContainer?
    var context: ModelContext?
    
    init() {
        do {
            container = try ModelContainer(for: JournalEntry.self)
            if let container = container {
                context = ModelContext(container)
            }
        } catch {
            print(error.localizedDescription)
        }
    }
    
    func fetchJournalEntries() -> [JournalEntry] {
        let descriptor = FetchDescriptor<JournalEntry>(sortBy: [SortDescriptor<JournalEntry>(\.date)])
        if let context = context {
            do {
                let journalEntries = try context.fetch(descriptor)
                return journalEntries
            } catch {
                print(error.localizedDescription)
            }
        }
        return []
    }
    
    func saveJournalEntry(journalEntry: JournalEntry) {
        if let context = context {
            context.insert(journalEntry)
        }
    }
    
    func deleteJournalEntry(journalEntry: JournalEntry) {
        if let context = context {
            context.delete(journalEntry)
        }
    }
}
