//
//  SharedData.swift
//  JRNL
//
//  Created by myadmin on 14/08/2023.
//

import Foundation
import SwiftData

class SharedData {
    static var shared = SharedData()
    var container: ModelContainer?
    var context: ModelContext?
    
    init() {
        do {
            container = try ModelContainer(for: [JournalEntry.self])
            if let container {
                context = ModelContext(container)
            }
            
        } catch {
            print(error)
        }
    }
    
    func fetchJournalEntries(onCompletion: @escaping ([JournalEntry]?, Error?) -> (Void)) {
        let descriptor = FetchDescriptor<JournalEntry>(sortBy: [SortDescriptor<JournalEntry>(\.date)])
        if let context = context {
            do {
                let data = try context.fetch(descriptor)
                onCompletion(data, nil)
            } catch {
                onCompletion(nil, error)
            }
        }
    }
    
    func saveJournalEntry(journalEntry: JournalEntry?) {
        guard let journalEntry = journalEntry else {
            return
        }
        if let context = context {
            context.insert(journalEntry)
        }
    }
    
    func deleteJournalEntry(journalEntry: JournalEntry) {
        if let context {
            context.delete(journalEntry)
        }
    }
}
