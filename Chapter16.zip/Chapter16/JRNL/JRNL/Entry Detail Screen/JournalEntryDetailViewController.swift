//
//  JournalEntryDetailViewController.swift
//  JRNL
//
//  Created by myadmin on 28/04/2023.
//

import UIKit

class JournalEntryDetailViewController: UITableViewController {
    
    //MARK: - Properties
    
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var bodyTextView: UITextView!
    @IBOutlet var photoImageView: UIImageView!
    
    var journalEntry: JournalEntry?

    override func viewDidLoad() {
        super.viewDidLoad()
        dateLabel.text = journalEntry?.date.formatted(
            .dateTime
                .day().month(.wide).year()
        )
        titleLabel.text = journalEntry?.entryTitle
        bodyTextView.text = journalEntry?.entryBody
        photoImageView.image = journalEntry?.photo
    }

}
