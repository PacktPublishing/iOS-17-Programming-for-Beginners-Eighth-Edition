//
//  JournalListTableViewCell.swift
//  JRNL
//
//  Created by myadmin on 25/04/2023.
//

import UIKit

class JournalListTableViewCell: UITableViewCell {
    //MARK: - Properties
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!
}
