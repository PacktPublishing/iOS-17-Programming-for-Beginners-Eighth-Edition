//
//  ViewController.swift
//  JRNL
//
//  Created by iOS17Programming on 25/09/2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

