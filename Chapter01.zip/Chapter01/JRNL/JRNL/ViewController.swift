//
//  ViewController.swift
//  JRNL
//
//  Created by iOS17Programming on 03/07/2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

