//
//  ViewController.swift
//  JRNL
//
//  Created by iOS17Programming on 12/06/2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

