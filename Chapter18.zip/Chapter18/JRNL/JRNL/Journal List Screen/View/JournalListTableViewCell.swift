//
//  JournalListTableViewCell.swift
//  JRNL
//
//  Created by iOS17Programming on 05/10/2023.
//

import UIKit

class JournalListTableViewCell: UITableViewCell {
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!

}
