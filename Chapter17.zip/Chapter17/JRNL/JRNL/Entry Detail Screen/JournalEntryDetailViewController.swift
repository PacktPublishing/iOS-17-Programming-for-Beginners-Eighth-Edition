//
//  JournalEntryDetailViewController.swift
//  JRNL
//
//  Created by myadmin on 28/04/2023.
//

import UIKit
import MapKit

class JournalEntryDetailViewController: UITableViewController {
    
    //MARK: - Properties
    
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var bodyTextView: UITextView!
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var mapImageView: UIImageView!
    
    var journalEntry: JournalEntry?

    override func viewDidLoad() {
        super.viewDidLoad()
        dateLabel.text = journalEntry?.date.formatted(
            .dateTime
                .day().month(.wide).year()
        )
        titleLabel.text = journalEntry?.entryTitle
        bodyTextView.text = journalEntry?.entryBody
        photoImageView.image = journalEntry?.photo
        getMapSnapshot()
    }
    
    // MARK: - Private
    private func getMapSnapshot(){
        if let lat = journalEntry?.latitude, let long = journalEntry?.longitude {
            let options = MKMapSnapshotter.Options()
            options.region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: lat, longitude: long), span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
            options.size = CGSize(width: 300, height: 300)
            options.showsBuildings = true
            options.pointOfInterestFilter = .includingAll
            let snapShotter = MKMapSnapshotter(options: options)
            snapShotter.start { snapshot, error in
                if let snapshot = snapshot {
                    self.mapImageView.image = snapshot.image
                } else if let error = error {
                    print("Error  \(error.localizedDescription)")
                }
            }
        } else {
            self.mapImageView.image = nil
        }
    }

}
