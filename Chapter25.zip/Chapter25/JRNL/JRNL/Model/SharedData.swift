//
//  SharedData.swift
//  JRNL
//
//  Created by myadmin on 16/05/2023.
//

import UIKit

class SharedData {
    
    //MARK: - Properties
    
    static let shared = SharedData()
    private var journalEntries: [JournalEntry]
    
    //MARK: - Access Methods
    
    func numberOfJournalEntries() -> Int {
        journalEntries.count
    }
    
    func getJournalEntry(index: Int) -> JournalEntry {
        journalEntries[index]
    }
    
    func getAllJournalEntries() -> [JournalEntry] {
        let readOnlyJournalEntries = journalEntries
        return readOnlyJournalEntries
    }
    
    func addJournalEntry(journalEntry: JournalEntry) {
        journalEntries.append(journalEntry)
    }
    
    func removeJournalEntry(index: Int) {
        journalEntries.remove(at: index)
    }
    
    func removeSelectedJournalEntry(_ selectedJournalEntry: JournalEntry) {
        journalEntries.removeAll(where: {
            $0.key == selectedJournalEntry.key
        })
    }
    
    //MARK: - Private
    
    private init() {
        journalEntries = []
    }
    
    //MARK: - Persistence
    
    func getAppGroupContainer() -> URL {
      let appIdentifier = "group.com.packt.jrnl"
      let fileManager = FileManager.default
      let containerURL = fileManager.containerURL(forSecurityApplicationGroupIdentifier: appIdentifier)
      return containerURL!
    }
    
    func loadJournalEntriesData() {
        let pathDirectory = getAppGroupContainer()
        let fileUrl = pathDirectory.appendingPathComponent("journalEntriesData.json")
        do {
            let data = try Data(contentsOf: fileUrl)
            let journalEntriesData = try JSONDecoder().decode([JournalEntry].self, from: data)
            journalEntries = journalEntriesData
        } catch {
            print("Failed to read JSON data: \(error.localizedDescription)")
        }
    }
    
    func saveJournalEntriesData() {
        let pathDirectory = getAppGroupContainer()
        try? FileManager().createDirectory(at: pathDirectory, withIntermediateDirectories: true)
        let filePath = pathDirectory.appendingPathComponent("journalEntriesData.json")
        let json = try? JSONEncoder().encode(journalEntries)
        do {
            try json!.write(to: filePath)
        } catch {
            print("Failed to write JSON data: \(error.localizedDescription)")
        }
    }
}

