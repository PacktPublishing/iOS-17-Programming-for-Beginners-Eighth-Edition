//
//  JRNLWidgetBundle.swift
//  JRNLWidget
//
//  Created by iOS17Programming on 17/10/2023.
//

import WidgetKit
import SwiftUI

@main
struct JRNLWidgetBundle: WidgetBundle {
    var body: some Widget {
        JRNLWidget()
    }
}
