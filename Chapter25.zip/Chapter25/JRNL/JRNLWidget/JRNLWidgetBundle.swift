//
//  JRNLWidgetBundle.swift
//  JRNLWidget
//
//  Created by myadmin on 29/08/2023.
//

import WidgetKit
import SwiftUI

@main
struct JRNLWidgetBundle: WidgetBundle {
    var body: some Widget {
        JRNLWidget()
    }
}
