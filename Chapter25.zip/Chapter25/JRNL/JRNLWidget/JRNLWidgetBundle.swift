//
//  JRNLWidgetBundle.swift
//  JRNLWidget
//
//  Created by shah on 14/10/2023.
//

import WidgetKit
import SwiftUI

@main
struct JRNLWidgetBundle: WidgetBundle {
    var body: some Widget {
        JRNLWidget()
    }
}
